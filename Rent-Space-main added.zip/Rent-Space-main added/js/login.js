// Form Elements
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const togglePassword = document.querySelector('.toggle-password');
const rememberCheckbox = document.getElementById('remember');
const tabButtons = document.querySelectorAll('.tab-btn');
const loginBtn = document.querySelector('.login-btn');
const spinner = document.querySelector('.spinner');

// Show/Hide Password
togglePassword.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePassword.classList.toggle('fa-eye');
    togglePassword.classList.toggle('fa-eye-slash');
});

// Tab Switching
tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
    });
});

// Form Submission
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Show loading state
    loginBtn.disabled = true;
    spinner.style.display = 'block';
    loginBtn.querySelector('span').style.opacity = '0';

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Check if remember me is checked
        if (rememberCheckbox.checked) {
            localStorage.setItem('rememberedEmail', emailInput.value);
        } else {
            localStorage.removeItem('rememberedEmail');
        }

        // Redirect based on user type
        const activeTab = document.querySelector('.tab-btn.active').dataset.tab;
        if (activeTab === 'user') {
            window.location.href = 'home.html';
        } else {
            window.location.href = 'owner-dashboard.html';
        }
    } catch (error) {
        // Reset button state
        loginBtn.disabled = false;
        spinner.style.display = 'none';
        loginBtn.querySelector('span').style.opacity = '1';
    }
});

// Google Login
document.querySelector('.google-btn').addEventListener('click', () => {
    // Implement Google OAuth login
    console.log('Google login clicked');
});

// Check for remembered email
const rememberedEmail = localStorage.getItem('rememberedEmail');
if (rememberedEmail) {
    emailInput.value = rememberedEmail;
    rememberCheckbox.checked = true;
} 