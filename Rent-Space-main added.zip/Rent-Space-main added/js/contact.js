// Form Elements
const contactForm = document.querySelector('.contact-form');
const submitBtn = document.querySelector('.submit-btn');
const spinner = document.querySelector('.spinner');

// Form Submission
contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Show loading state
    submitBtn.disabled = true;
    spinner.style.display = 'block';
    submitBtn.querySelector('span').style.opacity = '0';

    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Reset form
        contactForm.reset();

        // Show success message
        alert('Thank you for your message. We will get back to you soon!');
    } catch (error) {
        // Show error message
        alert('Sorry, there was an error sending your message. Please try again.');
    } finally {
        // Reset button state
        submitBtn.disabled = false;
        spinner.style.display = 'none';
        submitBtn.querySelector('span').style.opacity = '1';
    }
}); 